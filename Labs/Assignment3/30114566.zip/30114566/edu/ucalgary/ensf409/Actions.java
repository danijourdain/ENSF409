package edu.ucalgary.ensf409;

public enum Actions {
    FORWARD {},
    LEFT {},
    REVERSE {},
    RIGHT {},
    START {},
    STOP {};
}
